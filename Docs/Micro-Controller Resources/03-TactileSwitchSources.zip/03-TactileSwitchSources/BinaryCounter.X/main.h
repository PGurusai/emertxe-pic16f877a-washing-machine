/* 
 * File:   main.h
 * Author: Adil
 *
 * Created on 15 April, 2020, 8:30 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY1              PORTD
#define LED_ARRAY1_DDR          TRISD

#define OFF                     0x00

#endif	/* MAIN_H */

